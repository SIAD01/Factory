package com.example;

public class NotificationFactory {
    private NotificationFactory() {}

    public static Notification creer(String type) {
        switch (type.toLowerCase()) {
            case "email": return new EmailNotification();
            case "sms":   return new SmsNotification();
            case "push":  return new PushNotification();
            default:
                throw new IllegalArgumentException("Type inconnu : " + type);
        }
    }
}
