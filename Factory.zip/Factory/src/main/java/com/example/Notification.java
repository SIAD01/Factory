package com.example;

public interface Notification {
    public void envoyer(String message);
}