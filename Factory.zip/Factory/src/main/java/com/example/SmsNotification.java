package com.example;

public class SmsNotification implements Notification {

    @Override
    public void envoyer(String message) {
        System.out.println("SMS envoyé : " + message);
    }
}

