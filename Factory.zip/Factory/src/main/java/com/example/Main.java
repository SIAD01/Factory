package com.example;

public class Main {
    public static void main(String[] args) {
        Notification email = NotificationFactory.creer("email");
        email.envoyer("Bonjour - Test");

        Notification sms = NotificationFactory.creer("sms");
        sms.envoyer("Hello - Sms");

        Notification push = NotificationFactory.creer("push");
        push.envoyer("Notification push importante");
    }
}
