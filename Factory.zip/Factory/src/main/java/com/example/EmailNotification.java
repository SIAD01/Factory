package com.example;

public class EmailNotification implements Notification {

    @Override
    public void envoyer(String message) {
        System.out.println("Email envoyé : " + message);
    }
}

