package com.example;

public class PushNotification implements Notification {

    @Override
    public void envoyer(String message) {
        System.out.println("Push envoyé : " + message);
    }
}
